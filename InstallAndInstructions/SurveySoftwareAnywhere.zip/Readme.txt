SURVEY SYSTEM ANYWHERE
LIZARD LEAGUE SOFTWARE
 

System Requirements

Survey Software Anywhere operates within the Microsoft Windows environment and does not require any specialized hardware outside that environment.  We do recommend the user has installed Microsoft Windows XP or later and the following for the most efficient interaction with your system:

�	1 gigahertz (GHz) or faster 32-bit (x86) or 64-bit (x64) processor
�	1 gigabyte (GB) RAM (32-bit) or 2 GB RAM (64-bit)
�	1 GB available hard disk space (32-bit) 
�	DirectX 9 graphics device with WDDM 1.0 or higher driver

Survey Software Anywhere requires Java to run.  We recommend at a minimum version 1.4.0 or greater.  I you do not already have Java installed on your computer it can be downloaded at http://java.sun.com.  

Installation

Download the Survey Software Anywhere zip file from the following location: 

https://github.com/UIS-CSC478-project/survey-software/tree/master/InstallAndInstructions

�	Extract the SurveySoftwareAnywhere.zip to a folder on your machine where you have write permissions.  If the permissions are not correct, you will receive errors when the software tries to access its database.
�	To start using Survey Software Anywhere, double-click on the file SurveySoftwareAnywhere.jar. 
�	Included in the zip file is a Users' Manual, the License file, and a ReadMe.  Review these documents before first use of Survey Software Anywhere.

OutStanding Bugs

--Survey Takers feature not implemented.  Will be implemented in a future version.

--Scroll bars are slow.  If one clicks on the up or down arrows for the scrollbars, the movement up or down is very slow.

--Appearance of Give Survey screen needs to be more user friendly.  The layout needs to not have as much blank space as it currently has.

--Users can submit blank entries on the Create Survey page. This has effects on the Give Survey screen as well as the Survey Results screen.

--If there are no results to be shown, the Show Results feature generates an error.

